import React from 'react'

export const Storage =() => {


    
    return (
    <>
    <h1 className='text-center'>storage Data is receive by redux  </h1>
  
    </>
  )
}
