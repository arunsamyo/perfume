
 const Data=[
 {
        id:1,
        image:"./photo/img1.jpg",
        name:"AwakeMonk",
        price:499,
        Quantity:1
},
{
    id:2,
    image:"./photo/image7.jpg",
    name:"TeenHug",
    price:399,
    Quantity:1
},
{
    id:3,
    image:"./photo/img3.jpg",
    name:"TreshCheck",
    price:599,
    Quantity:1
},
{
    id:4,
    image:"./photo/img4.jpg",
    name:"XoomLady",
    price:699,
    Quantity:1
},
{
    id:5,
    image:"./photo/image1.jpg",
    name:"Hugo Boss.",
    price:699,
    Quantity:1
},
{
    id:6,
    image:"./photo/product2.jpg",
    name:"Elizabeth Arden.",
    price:599,
    Quantity:1
},
{
    id:7,
    image:"./photo/product3.jpg",
    name:"Versace",
    price:399,
    Quantity:1

},
{
    id:8,
    image:"./photo/image9.jpg",
    name:"Paco Rabanne",
    price:499,
    Quantity:1
},
{
    id:9,
    image:"./photo/image2.jpg",
    name:"Azzaro",
    price:999,
    Quantity:1
},
{
    id:10,
    image:"./photo/image3.jpg",
    name:"Beardo",
     price:799,
     Quantity:1
    
},
{
    id:11,
    image:"./photo/image4.jpg",
    name:"BLEU",
    price:899,
    Quantity:1
},
{
    id:12,
    image:"./photo/image5.jpg",
    name:"Creed",
    price:999,
    Quantity:1
},
];

export default Data;
